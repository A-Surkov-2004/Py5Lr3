from setuptools import setup

setup(name='OpenWeatherCityStatsSurkovIVT',
      version='0.0',
      description='Get data about weather in city by it\'s name',
      packages=['OpenWeatherCityStatsSurkovIVT'],
      author_email='andrey.surk.2904@gmail.com',
      zip_safe=False)