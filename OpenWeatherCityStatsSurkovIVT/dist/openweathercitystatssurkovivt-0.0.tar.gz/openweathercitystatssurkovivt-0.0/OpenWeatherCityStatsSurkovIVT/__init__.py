from .getweatherdata import get_weather_data
